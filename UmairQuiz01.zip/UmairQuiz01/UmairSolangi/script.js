
function performSearch() {
    const searchInput = document.getElementById('search-input').value.toLowerCase();
    const cards = document.querySelectorAll('.card');
    const cardid = document.getElementById('cardid');

    var searchFound = false;

    for (var i = 0; i < cards.length; i++) {
        const card = cards[i];
        const cardText = (card.textContent || '').toLowerCase();
        
        if (cardText.includes(searchInput)) {
            card.style.display = 'block';
            searchFound = true;
            // cardid.style.backgroundColor = 'yellow';
            console.log(searchInput.textContent);
        } else {
            card.style.display = 'none';
            // cardid.style.backgroundColor = 'red';
        }
    }
    
}
